<?php

namespace App\Http\Controllers\User;
use Gate;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Reclamation;
use Illuminate\Support\Facades\Validator;
class ReclamationsController extends Controller
{
  
  
  
  
  
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reclamations = Reclamation::all();
        return view('user.reclamations.index')->with('reclamations', $reclamations);
     }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        return view('user.reclamations.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
        
        'sujet'=>'required',
        'descreption'=>'required'
         ] );
    
            
        $reclamations=new Reclamation;
        $reclamations->user_id = auth()->user()->id;
        $reclamations->sujet= $request->input('sujet');
        $reclamations->type= $request->input('type');
        $reclamations->delivery_id= $request->input('delivery_number');
        $reclamations->description= $request->input('descreption');
        $reclamations->save();
        
        return redirect()->route('user.reclamations.index')->with('success', 'Reclamation Created successfuly');
    
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
     
   

    public function show(Reclamation $reclamation)

    {
        
        $data = array(
            'reclamation' => $reclamation,
            
        );
        return view('user.reclamations.show')->with($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

     public function edit(Request $request, Reclamation $reclamation)
    {
  
                    return view('user.reclamations.edit')->with([
                        'reclamation' => $reclamation,
                        
                        
                    ]); 
               
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,Reclamation $reclamation)
    {
        
        $validator = Validator::make($request->all(), [ 
            'sujet'=>'required',
            'descreption'=>'required'
        ]);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $request->session()->put('errors', $messages);
            return redirect()->route('user.reclamations.edit', $reclamation);
        }
        $reclamations = reclamations::where('$reclamation->user_id', '=', auth()->user()->id);
            $reclamations->user_id = auth()->user()->id;
            $reclamations->sujet= $request->get('sujet');
            $reclamations->type= $request->get('type');
            $reclamations->delivery_id= $request->get('delivery_number');
            $reclamations->description= $request->get('descreption');
            
            

            if($reclamations->save())
            $request->session()->flash('success');
            else
            $request->session()->flash('error');


            return redirect()->route('user.reclamations.index')->with('success', 'Reclamation Created successfuly');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,Reclamation $reclamation)
    {
        if(auth()->user()->id == $reclamation->user_id)
        {
            if($reclamation->delete())
            {
                $request->session()->flash('success',  'success your reclamation has been deleted');
            }
            else
            {
                $request->session()->flash('error', 'There was an error deleting the reclamation ');
            }

            return redirect()->route('user.reclamations.index');
        }
        else
        {
            return redirect()->route('user.reclamations.index')->with('error', 'Unauthorized Page, Your not allowed to perform this action');
        }
    }
}
