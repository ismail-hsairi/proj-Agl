@extends('layouts.app')

@section('content')
    <div class="jumbotron text-center">
        <h1>Welcome to our App</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea dolor dolores itaque! Nisi assumenda magni, fuga saepe veritatis soluta sed maiores eveniet amet adipisci libero! Distinctio pariatur excepturi illum perspiciatis.</p>
        <p><a class="btn btn-primary btn-lg" href="/login" role="button">Login</a> <a class="btn btn-success btn-lg" href="/register" role="button">Register</a></p>
    </div>
@endsection
        