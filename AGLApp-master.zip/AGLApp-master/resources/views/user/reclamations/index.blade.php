@extends('layouts.app')

@section('content')
    <h1>Listes des Reclamations</h1>
    @if (count($reclamations) > 0)
        @foreach($reclamations as $reclamation)
          <div class="card mb-5">
            <div class="card-header">
             {{ $reclamation->user_id }}
            </div>
            <div class="card-body">
              <h5 class="card-title">Subject: {{ $reclamation->sujet }}</h5>
              <p class="card-text">Description: {{ $reclamation->description }}</p>
              <hr>
              
              <a href="{{ route('user.reclamations.show', $reclamation) }}" class="btn btn-primary">Check this reclamation</a>
            </div>
          </div>
        @endforeach
      
    @else
        <h2 class="text-center">Aucune Reclamation</h2>
    @endif
@endsection