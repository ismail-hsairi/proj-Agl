

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('user.reclamations.index')); ?>" class="btn btn-danger">Go Back</a>
    
    <h1>Type : <?php echo e($reclamation->type); ?></h1>
    <h4>By : <?php echo e($reclamation->user_id); ?></h4>
    <h4>Delivery number : <?php echo e($reclamation->delivery_id); ?></h4>
    <h4>Subjcet : <?php echo e($reclamation->sujet); ?></h4>
    <div>
       Description: <?php echo $reclamation->description; ?>

    </div>
    
    <hr>
    <small>Written on <?php echo e($reclamation->created_at); ?><br></small>
    </hr>
    <?php if(auth()->guard()->check()): ?>
       
            <?php if(Auth::user()->id == $reclamation->user_id): ?>
                <a href="<?php echo e(route('user.reclamations.edit', $reclamations)); ?>"><button type="button" class="btn btn-success btn-lg float-left">Edit</button></a>
                <form action="<?php echo e(route('user.reclamations.destroy', $reclamation)); ?>" method="POST" class="float-right">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-lg btn-secondary">Delete</button>
                </form>    
         
       
        <?php endif; ?>
            
            
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\AGLApp-master\AGLApp-master\resources\views/user/reclamations/show.blade.php ENDPATH**/ ?>