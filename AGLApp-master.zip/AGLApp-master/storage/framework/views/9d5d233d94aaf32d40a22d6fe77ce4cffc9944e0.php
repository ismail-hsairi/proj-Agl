<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-danger">Go Back</a>
    
    <h1><?php echo e($reservation->donation->item->name); ?></h1>
    <h4>By : <?php echo e($reservation->demand->user->name); ?></h4>
    <div>
        <p><?php echo $reservation->demand->description; ?></p>
        <p>Quantity : <?php echo e($reservation->demand->qty); ?></p>
    </div>
    <hr>


        <!-- Button trigger modal -->
        <center><button type="button" class="btn btn-lg btn-outline-dark mt-2" data-toggle="modal" data-target="#staticBackdrop">
            Verify Delevery
        </button></center> 

        <!-- Modal -->
        <div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            
            <div class="modal-dialog" role="document">
                
                <div class="modal-content">
                    
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Proccessing delevey info</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['giver-role', 'admin-role'])): ?>
                            <?php if($reservation->giver_delivery_man == -1): ?>
                                <form method="POST" action="<?php echo e(route('contact.delivery.update', $reservation->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('PUT')); ?>


                                    <div class="form-row">
                                    <div class="col">
                                        <fieldset disabled>
                                            <input type="text" name="availability" class="form-control" value="<?php echo e($reservation->donation->availability); ?>">
                                        </fieldset>
                                    </div>
                                    <div class="col">
                                            <fieldset disabled>
                                                <input type="text" class="form-control" name="location" value="<?php echo e($reservation->donation->location); ?>">
                                            </fieldset>
                                        </div>
                                    </div>

                                    <div class="mt-3">
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" id="customRadioInline1" value="1" name="giver_delivery_man" class="custom-control-input">
                                            <label class="custom-control-label" for="customRadioInline1">You have delevery man</label>
                                        </div>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" id="customRadioInline2" value="0" name="giver_delivery_man" class="custom-control-input">
                                            <label class="custom-control-label" for="customRadioInline2">You don't have delevery man</label>
                                        </div>
                                    </div>

                                    <center> <button type="submit" class="btn btn-outline-dark mt-4">Send</button> </center> 
                                </form>    
                            <?php else: ?>
                                <?php if($reservation->giver_delivery_man == 0): ?>
                                    <center> 
                                        <div class="spinner-grow" role="status">
                                            <span class="sr-only">Loading...</span>
                                        </div>  
                                        
                                        <h3>Wating for Applicant to fill Delevery info</h3>
                                    </center>   
                                <?php endif; ?>
                                
                            <?php endif; ?>

                            
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicant-role')): ?>
                            <?php if($reservation->giver_delivery_man == -1): ?>
                                <center> 
                                    <div class="spinner-grow" role="status">
                                        <span class="sr-only">Loading...</span>
                                    </div>  
                                    
                                    <h3>Wating for Giver to fill Delevery info</h3>
                                </center>
                            <?php else: ?>
                                <?php if($reservation->giver_delivery_man == 0): ?>
                                    <form method="POST" action="<?php echo e(route('contact.delivery.update', $reservation)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('PUT')); ?>

                                        
                                        <div class="mt-3">
                                            
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline1" value="1" name="applicant_delivery_man" class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline1">You have delevery man</label>
                                            </div>
                                            
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline2" value="0" name="applicant_delivery_man" class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline2">You don't have delevery man</label>
                                            </div>

                                        </div>
        
                                        <center> <button type="submit" class="btn btn-outline-dark mt-4">Send</button> </center> 
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>


                          
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>

                </div>

            </div>

        </div>
            
       
    
    
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Projet AGL\AGLApp-master\resources\views/applicant/reservations/show.blade.php ENDPATH**/ ?>