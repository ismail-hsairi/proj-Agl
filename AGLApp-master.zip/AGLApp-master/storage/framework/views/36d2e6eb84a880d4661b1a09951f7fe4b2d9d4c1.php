<?php $__env->startSection('content'); ?>
    <!-- This what the users will see -->
    <a href="<?php echo e(route('giver.donations.index')); ?>" class="btn btn-danger">Go Back</a>
    
    <h1><?php echo e($donation->item->subject->name); ?></h1>
    <h4>By : <?php echo e($donation->user->name); ?></h4>
    <div>
        <?php echo $donation->description; ?> <br>
        The quantity : <?php echo e($donation->qty); ?>

    </div>
    <h5>Ce dont sera disponible le : <?php echo e($donation->availability); ?></h5>
    <hr>
    <small>Written on <?php echo e($donation->created_at); ?></small>
    <hr>
    
    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->id == $donation->user_id): ?>
            <a href="<?php echo e(route('giver.donations.edit', $donation)); ?>"><button type="button" class="btn btn-success btn-lg float-left">Edit</button></a>
            <form action="<?php echo e(route('giver.donations.destroy', $donation)); ?>" method="POST" class="float-right">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <button type="submit" class="btn btn-lg btn-secondary">Delete</button>
            </form>
        <?php endif; ?>
    
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicant-role')): ?>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-lg btn-primary ml-3" data-toggle="modal" data-target="#staticBackdrop">
                Reservation
            </button>

            <!-- Modal -->
            <div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">Make Reservation</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php if($ext == 0): ?>
                                <form action="<?php echo e(route('applicant.reservations.store', $donation)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="col">
                                            <!-- the demandes that belogs to the same item in the donation that the applicant did-->
                                            <?php if(count($demands) > 0): ?>
                                                <select class="form-control" id="demand_id" name="demand_id">
                                                    <option value="none">Select Your Demand</option>
                                                        
                                                        <?php
                                                            //init counter
                                                            $n = 0;
                                                        ?>

                                                        <?php $__currentLoopData = $demands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($donation->qty >= $demand->qty): ?>
                                                                
                                                                <?php
                                                                //counting the numbers of demands that have an appropriate quantity
                                                                $n++;    
                                                                ?>
                                                                <option value="<?php echo e($demand->id); ?>"><?php echo e($demand->created_at); ?> -- Quantity required <?php echo e($demand->qty); ?></option>    
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <div class="col" style="display:none">
                                                    <input type="text" class="form-control" name="donation_id" value="<?php echo e($donation->id); ?>">
                                                </div>

                                                <?php if($n >0 ): ?>
                                                    <center><button type="submit" class="btn btn-primary mt-4">Verify Reservation</button></center>    
                                                <?php else: ?>
                                                    <div class="alert alert-danger mt-5" role="alert">
                                                        You don't have any demands with an appropriate quantity
                                                    </div>    
                                                <?php endif; ?>
                                                
                                            <?php else: ?>
                                                <div class="alert alert-danger" role="alert">
                                                    You don't have any demands goes with this donation
                                                </div>                
                                            <?php endif; ?>
                                                
                                        </div>
                                        
                                    </div>
                                        
                                </form>
                            <?php else: ?>
                                <div class="alert alert-danger" role="alert">
                                    You have already sent a reservation request
                                </div>
                            <?php endif; ?>
                                
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\AGLApp-master\AGLApp-master\resources\views/giver/donations/show.blade.php ENDPATH**/ ?>