<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('applicant.demands.index')); ?>" class="btn btn-danger">Go Back</a>
    
    <h1><?php echo e($demand->item->subject->name); ?></h1>
    <h4>By : <?php echo e($demand->user->name); ?></h4>
    <div>
        <?php echo $demand->description; ?>

    </div>
    <h5>Cette demande expire: <?php echo e($demand->dl); ?></h5>
    <hr>
    <small>Written on <?php echo e($demand->created_at); ?></small>
    <hr>

    <?php if(auth()->guard()->check()): ?>
        <?php if($acc_dem == 0): ?>
            <?php if(Auth::user()->id == $demand->user_id): ?>
                <a href="<?php echo e(route('applicant.demands.edit', $demand)); ?>"><button type="button" class="btn btn-success btn-lg float-left">Edit</button></a>
                <form action="<?php echo e(route('applicant.demands.destroy', $demand)); ?>" method="POST" class="float-right">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-lg btn-secondary">Delete</button>
                </form>    
            <?php endif; ?>
        <?php else: ?>
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Well done!</h4>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("applicant-role")): ?>
                        <p>Your demand has been accepted and the reservation that belogs to this demand is ready for delevery !!!.</p>        
                    <?php else: ?>
                        <p>Your accepted this demand and the reservation that belogs to this demand is ready for delevery !!!.</p>        
                    <?php endif; ?>   
                
                <hr>
                <p class="mb-0">Pleas Check your notifications.</p>
            </div>
        <?php endif; ?>
            
            
    <?php endif; ?>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Projet AGL\AGLApp-master\resources\views/applicant/demands/show.blade.php ENDPATH**/ ?>